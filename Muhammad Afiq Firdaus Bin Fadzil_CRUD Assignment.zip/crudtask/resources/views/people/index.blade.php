@extends('people.layout')

@section('content')

 <div class="container" style="padding-top: 100px;">


    <div class = "pull-left">
        <h1>List Of People</h1>
    </div>
        <h2>Create New <a href="{{ route('people.create') }}" class="btn btn-secondary float-right">Create</a></h2>


    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }} </p>
        </div>
    @endif

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Contact</th>
            <th width=280px> Action</th>
        </tr>
        @foreach ($peoples as $person)
        <tr>

            <td>{{ ++$i }}</td>
            <td>{{ $person->name }}</td>
            <td>{{ $person->contact }}</td>
            <td>
                <form action="{{ route('people.destroy',$person->id) }}" method="POST">

                    <a class="btn btn-primary" href="{{ route('people.edit',$person->id)}}">Edit</a>

                    @csrf
                    @method('POST')

                    <button type="submit" class="btn btn-danger">DELETE</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
 </div>
</div>

