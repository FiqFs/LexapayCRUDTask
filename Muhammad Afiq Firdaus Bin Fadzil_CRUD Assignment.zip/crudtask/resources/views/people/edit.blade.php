@extends('people.layout')

@section('content')

<div class="container" style="padding-top: 100px;">
    <h1>Edit Person Details <a href="{{ route('people.index') }}" class="btn btn-secondary float-right">Back</a></h1>


    @if ($errors->any())
    <div class="alert alert-danger">
    <strong>Whoops!</strong> There are problems with the input.<br><br>
    <ul>
        @foreach ($errors->all() as $error)
        <li>{{$error}}</li>
        @endforeach
    </ul>
    </div>

    @endif

    <form action="{{ route('people.update',$person)}}" method="POST">
    @csrf
    @method('POST')
    <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label for="name">Full Name</label>
            <input class="form-control" value="{{$person->name}}" type="text" name="name" id="name">
        </div>


    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label for="contact">Contact</label>
            <input class="form-control" value="{{$person->contact}}" type="text" name="contact" id="contact">
        </div>

    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Update</button>
    </div>

    </div>
</form>

@endsection
