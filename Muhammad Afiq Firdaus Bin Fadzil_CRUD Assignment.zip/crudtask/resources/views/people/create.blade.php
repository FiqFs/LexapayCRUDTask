@extends('people.layout')

@section('content')

<div class="container" style="padding-top: 100px;">
    <h1>Add New Person <a href="{{ route('people.index') }}" class="btn btn-secondary float-right">Back</a></h1>


@if ($errors->any())
    <div class="alert alert-danger">
    <strong>Whoops!</strong> There are problems with the input.<br><br>
    <ul>
        @foreach ($errors->all() as $error)
        <li>{{$error}}</li>
        @endforeach
    </ul>
    </div>

    @endif

    <form action="{{ route('people.store')}}" method="POST">
    @csrf

    <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label for="name">Full Name</label>
            <input class="form-control"  type="text" name="name" id="name">
        </div>

    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label for="contact">Contact</label>
            <input class="form-control"  type="text" name="contact" id="contact">
        </div>

    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

    </div>
    </form>
</div>


@endsection
