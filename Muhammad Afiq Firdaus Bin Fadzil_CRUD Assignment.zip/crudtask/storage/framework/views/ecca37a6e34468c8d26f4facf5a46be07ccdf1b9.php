<?php $__env->startSection('content'); ?>

<div class="container" style="padding-top: 100px;">
    <h1>Add New Person <a href="<?php echo e(route('people.index')); ?>" class="btn btn-secondary float-right">Back</a></h1>


<?php if($errors->any()): ?>
    <div class="alert alert-danger">
    <strong>Whoops!</strong> There are problems with the input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>

    <?php endif; ?>

    <form action="<?php echo e(route('people.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label for="name">Full Name</label>
            <input class="form-control"  type="text" name="name" id="name">
        </div>

    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <label for="contact">Contact</label>
            <input class="form-control"  type="text" name="contact" id="contact">
        </div>

    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

    </div>
    </form>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('people.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\crudtask\resources\views/people/create.blade.php ENDPATH**/ ?>