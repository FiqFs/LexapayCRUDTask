<!DOCTYPE html>
<html>

<head>
    <title> List Management System </title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
          background-image: url("<?php echo e(asset ('assets/images/wallpaper2.jpeg')); ?>");
          background-repeat: no-repeat;
          background-attachment: fixed;
          background-size: cover;
        }
     </style>

</head>
<body>

    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html>
<?php /**PATH D:\laragon\www\crudtask\resources\views/people/layout.blade.php ENDPATH**/ ?>