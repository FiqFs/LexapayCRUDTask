<?php $__env->startSection('content'); ?>

 <div class="container" style="padding-top: 100px;">


    <div class = "pull-left">
        <h1>List Of People</h1>
    </div>
        <h2>Create New <a href="<?php echo e(route('people.create')); ?>" class="btn btn-secondary float-right">Create</a></h2>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?> </p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Contact</th>
            <th width=280px> Action</th>
        </tr>
        <?php $__currentLoopData = $peoples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>

            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($person->name); ?></td>
            <td><?php echo e($person->contact); ?></td>
            <td>
                <form action="<?php echo e(route('people.destroy',$person->id)); ?>" method="POST">

                    <a class="btn btn-primary" href="<?php echo e(route('people.edit',$person->id)); ?>">Edit</a>

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>

                    <button type="submit" class="btn btn-danger">DELETE</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
 </div>
</div>


<?php echo $__env->make('people.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\crudtask\resources\views/people/index.blade.php ENDPATH**/ ?>