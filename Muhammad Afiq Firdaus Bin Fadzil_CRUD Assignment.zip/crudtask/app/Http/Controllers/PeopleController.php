<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\People;

class PeopleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $peoples = People::latest()->paginate(5);
        return view('people.index',compact('peoples'))
            ->with('i',(request()->input('page',1) - 1) * 5);


       /* $persons= People::all();
        return view('people.index',compact('peoples'));*/
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
            return view('people.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request ->validate([
            'name' => 'required',
            'contact' => 'required',

        ]);

        $peoples =new People();
        $peoples->name=$request->get('name');
        $peoples->contact=$request->get('contact');
        $peoples->save();


        return redirect()->route('people.index')
            ->with('success','Person added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(People $person)
    {
        return view('people.edit',compact('person'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, People $person)
    {
        $request ->validate([
            'name' => 'required',
            'contact' => 'required',

        ]);


        $person->name=$request->get('name');
        $person->contact=$request->get('contact');
        $person->save();


        return redirect()->route('people.index')
            ->with('success','Person added successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(People $person)
    {
        $person->delete();

        return redirect()->route('people.index')
            ->with('success','Person deleted successfully');
    }
}
