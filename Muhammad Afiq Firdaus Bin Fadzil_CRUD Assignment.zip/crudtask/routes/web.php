<?php

use App\Http\Controllers\PeopleController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// Route::resource('people', PeopleController::class);

Route::get('/', [PeopleController::class, 'index'])->name('people.index');
Route::get('/people_create', [PeopleController::class, 'create'])->name('people.create');
Route::post('/people_store', [PeopleController::class, 'store'])->name('people.store');
Route::get('/people_edit/{person}', [PeopleController::class, 'edit'])->name('people.edit');
Route::post('/people_update/{person}', [PeopleController::class, 'update'])->name('people.update');
Route::post('/people_destroy/{person}', [PeopleController::class, 'destroy'])->name('people.destroy');
